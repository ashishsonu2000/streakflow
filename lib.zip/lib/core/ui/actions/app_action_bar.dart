import 'package:flutter/material.dart';

class AppActionBar extends StatelessWidget {
  const AppActionBar({
    super.key,
    required this.primary,
    required this.secondary,
  });

  final Widget primary;
  final Widget secondary;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: primary,
        ),
        const SizedBox(width: 12),
        Expanded(
          child: secondary,
        ),
      ],
    );
  }
}
