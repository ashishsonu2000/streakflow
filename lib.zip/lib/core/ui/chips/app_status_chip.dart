import 'package:flutter/material.dart';

import '../../../app/theme/app_colors.dart';

enum AppStatus {
  completed,
  pending,
  archived,
  missed,
  locked,
  unlocked,
  active,
  inactive,
}

enum StatusChipSize {
  small,
  medium,
}

class StatusChip extends StatelessWidget {
  const StatusChip({
    super.key,
    required this.status,
    this.label,
    this.icon,
    this.color,
    this.size = StatusChipSize.medium,
  });

  final AppStatus status;

  /// Override default label
  final String? label;

  /// Override default icon
  final IconData? icon;

  /// Override default colour
  final Color? color;

  final StatusChipSize size;

  @override
  Widget build(BuildContext context) {
    final chipColor = color ?? _defaultColor(context);
    final iconSize = size == StatusChipSize.small ? 14.0 : 16.0;
    final fontSize = size == StatusChipSize.small ? 11.0 : 12.5;
    final padding = size == StatusChipSize.small
        ? const EdgeInsets.symmetric(horizontal: 6)
        : const EdgeInsets.symmetric(horizontal: 8);

    return Chip(
      padding: padding,
      avatar: Icon(
        icon ?? _defaultIcon,
        size: iconSize,
        color: chipColor,
      ),
      label: Text(label ?? _defaultLabel),
      backgroundColor: chipColor.withOpacity(.12),
      side: BorderSide.none,
      visualDensity: VisualDensity.compact,
      materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
      labelStyle: TextStyle(
        color: chipColor,
        fontWeight: FontWeight.w600,
        fontSize: fontSize,
      ),
    );
  }

  String get _defaultLabel {
    switch (status) {
      case AppStatus.completed:
        return 'Completed';
      case AppStatus.pending:
        return 'Pending';
      case AppStatus.archived:
        return 'Archived';
      case AppStatus.missed:
        return 'Missed';
      case AppStatus.locked:
        return 'Locked';
      case AppStatus.unlocked:
        return 'Unlocked';
      case AppStatus.active:
        return 'Active';
      case AppStatus.inactive:
        return 'Inactive';
    }
  }

  Color _defaultColor(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;

    switch (status) {
      case AppStatus.completed:
        return AppColors.success;

      case AppStatus.pending:
        return AppColors.warning;

      case AppStatus.archived:
        return scheme.outline;

      case AppStatus.missed:
        return AppColors.error;

      case AppStatus.locked:
        return scheme.outline;

      case AppStatus.unlocked:
        return AppColors.gold;

      case AppStatus.active:
        return AppColors.primary;

      case AppStatus.inactive:
        return scheme.outline;
    }
  }

  IconData get _defaultIcon {
    switch (status) {
      case AppStatus.completed:
        return Icons.check_circle_outline_rounded;
      case AppStatus.pending:
        return Icons.schedule_rounded;
      case AppStatus.archived:
        return Icons.archive_outlined;
      case AppStatus.missed:
        return Icons.cancel_outlined;
      case AppStatus.locked:
        return Icons.lock_outline_rounded;
      case AppStatus.unlocked:
        return Icons.lock_open_rounded;
      case AppStatus.active:
        return Icons.play_circle_outline_rounded;
      case AppStatus.inactive:
        return Icons.pause_circle_outline_rounded;
    }
  }
}
