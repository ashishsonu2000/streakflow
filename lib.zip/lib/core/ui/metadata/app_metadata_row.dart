import 'package:flutter/material.dart';

class MetadataItem {
  final IconData icon;
  final String label;

  const MetadataItem({
    required this.icon,
    required this.label,
  });
}

class AppMetadataRow extends StatelessWidget {
  const AppMetadataRow({
    super.key,
    required this.items,
  });

  final List<MetadataItem> items;

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 16,
      runSpacing: 8,
      children: items.map((item) {
        return Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              item.icon,
              size: 16,
              color: Theme.of(context).colorScheme.primary,
            ),
            const SizedBox(width: 4),
            Text(item.label),
          ],
        );
      }).toList(),
    );
  }
}
