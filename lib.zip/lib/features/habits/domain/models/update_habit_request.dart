import '../../data/entities/habit_frequency.dart';
import 'habit.dart';
import 'habit_category.dart';

class UpdateHabitRequest {
  final Habit habit;

  final String title;

  final String description;

  final HabitCategory category;

  final HabitFrequency frequency;

  final int iconCodePoint;

  final int colorValue;

  final int targetPerDay;

  final bool reminderEnabled;

  final int? reminderHour;

  final int? reminderMinute;

  const UpdateHabitRequest({
    required this.habit,
    required this.title,
    required this.description,
    required this.category,
    required this.frequency,
    required this.iconCodePoint,
    required this.colorValue,
    required this.targetPerDay,
    required this.reminderEnabled,
    this.reminderHour,
    this.reminderMinute,
  });
}
