import '../../data/entities/habit_frequency.dart';
import '../models/habit_category.dart';
import 'habit.dart';

class HabitFormState {
  final String title;
  final String description;

  final HabitCategory category;
  final HabitFrequency frequency;

  final int iconCodePoint;
  final int colorValue;

  final bool isEditing;
  final bool isSaving;

  final String? error;
  final Habit? originalHabit;

  const HabitFormState({
    this.title = "",
    this.description = "",
    this.category = HabitCategory.personal,
    this.frequency = HabitFrequency.daily,
    this.iconCodePoint = 0xe3af, // Icons.check_circle
    this.colorValue = 0xFF4CAF50,
    this.isEditing = false,
    this.isSaving = false,
    this.error,
    this.originalHabit,
  });

  HabitFormState copyWith({
    String? title,
    String? description,
    HabitCategory? category,
    HabitFrequency? frequency,
    int? iconCodePoint,
    int? colorValue,
    bool? isEditing,
    bool? isSaving,
    String? error,
    Habit? originalHabit,
  }) {
    return HabitFormState(
      title: title ?? this.title,
      description: description ?? this.description,
      category: category ?? this.category,
      frequency: frequency ?? this.frequency,
      iconCodePoint: iconCodePoint ?? this.iconCodePoint,
      colorValue: colorValue ?? this.colorValue,
      isEditing: isEditing ?? this.isEditing,
      isSaving: isSaving ?? this.isSaving,
      error: error,
      originalHabit: originalHabit ?? this.originalHabit,
    );
  }

  bool get isValid => title.trim().isNotEmpty;
}
