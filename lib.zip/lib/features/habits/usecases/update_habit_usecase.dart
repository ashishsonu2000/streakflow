import '../domain/models/update_habit_request.dart';
import '../domain/repositories/habit_repository.dart';

class UpdateHabitUseCase {
  final HabitRepository _repository;

  UpdateHabitUseCase(this._repository);

  Future<void> call(
    UpdateHabitRequest request,
  ) async {
    await _repository.save(
      request.habit.copyWith(
        title: request.title,
        description: request.description,
        category: request.category,
        frequency: request.frequency,
        iconCodePoint: request.iconCodePoint,
        colorValue: request.colorValue,
        targetPerDay: request.targetPerDay,
        reminderEnabled: request.reminderEnabled,
        reminderHour: request.reminderHour,
        reminderMinute: request.reminderMinute,
        updatedAt: DateTime.now(),
      ),
    );
  }
}
