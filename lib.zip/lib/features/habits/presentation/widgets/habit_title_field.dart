import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../provider/habit_form_provider.dart';

class HabitTitleField extends ConsumerWidget {
  const HabitTitleField({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(habitFormProvider);

    return TextFormField(
      initialValue: state.title,
      decoration: const InputDecoration(
        labelText: "Habit Title",
        border: OutlineInputBorder(),
      ),
      textInputAction: TextInputAction.next,
      onChanged: (value) {
        ref.read(habitFormProvider.notifier).setTitle(value);
      },
    );
  }
}
