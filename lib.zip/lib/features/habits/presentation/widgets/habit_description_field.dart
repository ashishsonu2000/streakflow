import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../provider/habit_form_provider.dart';

class HabitDescriptionField extends ConsumerWidget {
  const HabitDescriptionField({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(habitFormProvider);

    return TextFormField(
      initialValue: state.description,
      decoration: const InputDecoration(
        labelText: "Description",
        border: OutlineInputBorder(),
      ),
      maxLines: 3,
      onChanged: (value) {
        ref.read(habitFormProvider.notifier).setDescription(value);
      },
    );
  }
}
