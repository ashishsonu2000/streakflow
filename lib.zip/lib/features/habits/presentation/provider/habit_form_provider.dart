import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../data/entities/habit_frequency.dart';
import '../../domain/models/habit.dart';
import '../../domain/models/habit_category.dart';
import '../../domain/models/habit_form_state.dart';

final habitFormProvider = NotifierProvider<HabitFormNotifier, HabitFormState>(
  HabitFormNotifier.new,
);

class HabitFormNotifier extends Notifier<HabitFormState> {
  @override
  HabitFormState build() {
    return const HabitFormState();
  }

  // ==========================
  // Basic Fields
  // ==========================

  void setTitle(String value) {
    state = state.copyWith(
      title: value,
    );
  }

  void setDescription(String value) {
    state = state.copyWith(
      description: value,
    );
  }

  // ==========================
  // Category
  // ==========================

  void setCategory(HabitCategory category) {
    state = state.copyWith(
      category: category,
    );
  }

  // ==========================
  // Frequency
  // ==========================

  void setFrequency(HabitFrequency frequency) {
    state = state.copyWith(
      frequency: frequency,
    );
  }

  // ==========================
  // Icon
  // ==========================

  void setIcon(int iconCodePoint) {
    state = state.copyWith(
      iconCodePoint: iconCodePoint,
    );
  }

  // ==========================
  // Color
  // ==========================

  void setColor(int colorValue) {
    state = state.copyWith(
      colorValue: colorValue,
    );
  }

  // ==========================
  // Loading
  // ==========================

  void setSaving(bool saving) {
    state = state.copyWith(
      isSaving: saving,
    );
  }

  // ==========================
  // Error
  // ==========================

  void setError(String? error) {
    state = state.copyWith(
      error: error,
    );
  }

  void clearError() {
    state = state.copyWith(
      error: null,
    );
  }

  // ==========================
  // Edit Mode
  // ==========================

  void setEditing(bool editing) {
    state = state.copyWith(
      isEditing: editing,
    );
  }

  // ==========================
  // Reset
  // ==========================

  void reset() {
    state = const HabitFormState();
  }

  // ==========================
  // Populate Existing Habit
  // (used in Edit screen)
  // ==========================

  void loadFromHabit(Habit habit) {
    state = HabitFormState(
      originalHabit: habit,
      title: habit.title,
      description: habit.description,
      category: habit.category,
      frequency: habit.frequency,
      iconCodePoint: habit.iconCodePoint,
      colorValue: habit.colorValue,
      isEditing: true,
    );
  }

  Habit buildHabit() {
    if (state.originalHabit == null) {
      throw Exception("No habit loaded");
    }

    return state.originalHabit!.copyWith(
      title: state.title.trim(),
      description: state.description.trim(),
      category: state.category,
      frequency: state.frequency,
      iconCodePoint: state.iconCodePoint,
      colorValue: state.colorValue,
      updatedAt: DateTime.now(),
    );
  }
  // ==========================
  // Validation
  // ==========================

  bool validate() {
    clearError();

    if (state.title.trim().isEmpty) {
      setError("Habit title is required.");
      return false;
    }

    return true;
  }
}
