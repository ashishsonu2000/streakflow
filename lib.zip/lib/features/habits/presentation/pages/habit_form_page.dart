import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../provider/habit_form_provider.dart';
import '../widgets/habit_description_field.dart';
import '../widgets/habit_title_field.dart';

class HabitFormPage extends ConsumerWidget {
  const HabitFormPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(habitFormProvider);

    return Scaffold(
      appBar: AppBar(
        title: Text(
          state.isEditing ? "Edit Habit" : "Add Habit",
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: const [
            HabitTitleField(),
            SizedBox(height: 20),
            HabitDescriptionField(),
            SizedBox(height: 40),
          ],
        ),
      ),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.all(20),
        child: FilledButton(
          onPressed: state.isValid && !state.isSaving
              ? () {
                  // Batch 7.8.4
                }
              : null,
          child: Text(
            state.isEditing ? "Update Habit" : "Create Habit",
          ),
        ),
      ),
    );
  }
}
