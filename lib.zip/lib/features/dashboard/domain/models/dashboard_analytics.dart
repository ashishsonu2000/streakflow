import '../../../../core/progression/models/level_summary.dart';
import '../../../calendar/domain/models/calendar_view_model.dart';
import '../../../statistics/domain/models/daily_statistics.dart';

import 'activity_item.dart';
import 'analytics_card_model.dart';
import 'heatmap_day.dart';

class DashboardAnalytics {
  const DashboardAnalytics({
    required this.currentStreak,
    required this.longestStreak,
    required this.totalHabits,
    required this.completedToday,
    required this.pendingToday,
    required this.weeklyCompletion,
    required this.monthlyCompletion,
    required this.completionRate,
    required this.progress,
    required this.perfectDays,
    required this.completedDays,
    required this.targetDays,
    required this.cards,
    required this.calendar,
    required this.weekly,
    required this.recentActivity,
    required this.heatmap,
    required this.levelSummary,
  });

  //------------------------------
  // Streak
  //------------------------------

  final int currentStreak;

  final int longestStreak;

  //------------------------------
  // Habit Metrics
  //------------------------------

  final int totalHabits;

  final int completedToday;

  final int pendingToday;

  final double weeklyCompletion;

  final double monthlyCompletion;

  final double completionRate;

  final double progress;

  //------------------------------
  // Calendar Metrics
  //------------------------------

  final int perfectDays;

  final int completedDays;

  final int targetDays;

  //------------------------------
  // Dashboard UI
  //------------------------------

  final List<AnalyticsCardModel> cards;

  final CalendarViewModel calendar;

  final List<DailyStatistics> weekly;

  final List<ActivityItem> recentActivity;

  final List<HeatmapDay> heatmap;

  final LevelSummary levelSummary;
}
