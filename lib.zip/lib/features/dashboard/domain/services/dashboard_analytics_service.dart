import '../../../../core/progression/calculators/level_calculator.dart';
import '../../../habits/data/entities/habit_log_entity.dart';

import '../../../habits/domain/calculators/metrics/metrics_calculator.dart';
import '../../../habits/domain/models/habit.dart';

import '../../../habits/domain/calculators/habit_metrics_calculator.dart';
import '../../../habits/domain/calculators/streak_calculator.dart';
import '../../../habits/domain/calculators/xp_calculator.dart';
import '../models/dashboard_analytics.dart';

import '../../../habits/domain/calculators/heatmap_calculator.dart';
import '../../../habits/domain/calculators/weekly_progress_calculator.dart';
import '../../../habits/domain/calculators/activity_calculator.dart';

class DashboardAnalyticsService {
  DashboardAnalyticsService({
    LevelCalculator? levelCalculator,
  }) : _levelCalculator = levelCalculator ?? const LevelCalculator();

  final LevelCalculator _levelCalculator;
    //------------------------------------
    // Streak
    //------------------------------------

    final totalXp = _calculateTotalXp(logs);

final levelSummary =
    _levelCalculator.calculate(totalXp);

    //------------------------------------
    // Metrics
    //------------------------------------

    final metrics = MetricsCalculator.calculate(
      habits,
      logs,
    );

    //------------------------------------
    // Weekly Progress
    //------------------------------------

    final weekly = WeeklyProgressCalculator.calculate(
      habits,
      logs,
    );

    //------------------------------------
    // Recent Activity
    //------------------------------------

    final activities = ActivityCalculator.calculate(logs);

    //------------------------------------
    // DashboardAnalytics
    //------------------------------------

    return DashboardAnalytics(
      currentStreak: streak.currentStreak,
      longestStreak: streak.longestStreak,
      totalHabits: metrics.totalHabits,
      completedToday: metrics.completedToday,
      pendingToday: metrics.pendingToday,
      weeklyCompletion: metrics.weeklyCompletion,
      monthlyCompletion: metrics.monthlyCompletion,
      completionRate: metrics.completionRate,
      progress: metrics.progress,
      totalXp: totalXP,
      level: level,
      xpTarget: xpTarget,
      achievement: achievement,
      perfectDays: streak.perfectDays,
      completedDays: streak.completedDays,
      targetDays: metrics.totalHabits == 0 ? 0 : metrics.totalHabits * 30,
      weeklyProgress: weekly,
      recentActivity: activities,
      heatmap: HeatmapCalculator.calculate(logs),
    );
  }
}
