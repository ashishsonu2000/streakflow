import '../../engine/calculator.dart';
import '../../engine/statistics_context.dart';
import '../../models/overview_statistics.dart';

import 'perfect_day_calculator.dart';
import 'streak_calculator.dart';

class OverviewCalculator
    implements Calculator<StatisticsContext, OverviewStatistics> {
  const OverviewCalculator();

  @override
  OverviewStatistics calculate(
    StatisticsContext context,
  ) {
    //------------------------------------------
    // Streak
    //------------------------------------------

    final streak = const StreakCalculator().calculate(
      context.logs,
    );

    //------------------------------------------
    // Perfect Days
    //------------------------------------------

    final perfectDays = const PerfectDayCalculator().calculate(
      context,
    );

    //------------------------------------------
    // XP
    //------------------------------------------

    final totalXP = context.logs.fold<int>(
      0,
      (sum, log) => sum + log.xpEarned,
    );

    //------------------------------------------
    // Duration
    //------------------------------------------

    final totalDuration = context.logs.fold<int>(
      0,
      (sum, log) => sum + log.durationMinutes,
    );

    //------------------------------------------
    // Completion Rate
    //------------------------------------------

    final completionRate = context.habits.isEmpty
        ? 0.0
        : context.logs.length / context.habits.length;

    return OverviewStatistics(
      completionRate: completionRate,
      currentStreak: streak.currentStreak,
      bestStreak: streak.longestStreak,
      totalHabits: context.habits.length,
      totalCompletions: context.logs.length,
      totalXP: totalXP,
      totalDurationMinutes: totalDuration,
      perfectDays: perfectDays,
    );
  }
}
