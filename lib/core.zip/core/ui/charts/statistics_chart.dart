import 'package:flutter/material.dart';

import '../cards/app_card.dart';

import 'chart_point.dart';
import 'chart_theme.dart';
import 'statistics_line_chart.dart';

class StatisticsChart extends StatelessWidget {
  const StatisticsChart({
    super.key,
    required this.title,
    required this.points,
  });

  final String title;

  final List<ChartPoint> points;

  @override
  Widget build(BuildContext context) {
    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: Theme.of(context).textTheme.titleLarge,
          ),
          const SizedBox(height: 20),
          SizedBox(
            height: ChartTheme.chartHeight,
            child: StatisticsLineChart(
              points: points,
            ),
          ),
        ],
      ),
    );
  }
}
