import 'package:flutter/material.dart';

import '../../../../dashboard/presentation/widgets/analytics/analytics_grid.dart';
import '../../../data/mapper/overview_mapper.dart';
import '../../../domain/models/overview_statistics.dart';

class OverviewSection extends StatelessWidget {
  const OverviewSection({
    super.key,
    required this.overview,
  });

  final OverviewStatistics overview;

  @override
  Widget build(BuildContext context) {
    final analytics = const OverviewMapper().map(overview);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Overview',
          style: Theme.of(context).textTheme.headlineSmall,
        ),
        const SizedBox(height: 16),
        AnalyticsGrid(
          analytics: analytics,
        ),
      ],
    );
  }
}
