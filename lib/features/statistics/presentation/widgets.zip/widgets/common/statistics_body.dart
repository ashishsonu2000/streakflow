import 'package:flutter/material.dart';

import '../../../../../core/ui/analytics/analytics_grid.dart';
import '../../../../../core/ui/charts/chart_data_mapper.dart';
import '../../../../../core/ui/charts/chart_type.dart';
import '../../../../../core/ui/charts/statistics_chart.dart';
import '../../../../../core/ui/insights/insights_list.dart';

import '../../../data/mapper/insight_mapper.dart';
import '../../../data/mapper/overview_mapper.dart';
import '../../../domain/models/statistics_summary.dart';

import '../performance/performance_section.dart';

class StatisticsBody extends StatelessWidget {
  const StatisticsBody({
    super.key,
    required this.statistics,
  });

  final StatisticsSummary statistics;

  @override
  Widget build(BuildContext context) {
    //------------------------------------------
    // Mappers
    //------------------------------------------

    final overviewMapper = const OverviewMapper();
    final insightMapper = const InsightMapper();
    final chartMapper = const ChartDataMapper();

    final analytics = overviewMapper.map(
      statistics.overview,
    );

    final insights = insightMapper.map(
      statistics.insights,
    );

    final chartPoints = chartMapper.map(
      trends: statistics.trends,
      type: ChartType.trend,
    );

    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(
        16,
        16,
        16,
        100,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          //------------------------------------------
          // Analytics
          //------------------------------------------

          AnalyticsGrid(
            analytics: analytics,
          ),

          const SizedBox(height: 24),

          //------------------------------------------
          // Charts
          //------------------------------------------

          StatisticsChart(
            title: '30 Day Progress',
            points: chartPoints,
          ),

          const SizedBox(height: 24),

          //------------------------------------------
          // Performance
          //------------------------------------------

          PerformanceSection(
            performance: statistics.performance,
          ),

          const SizedBox(height: 24),

          //------------------------------------------
          // Insights
          //------------------------------------------

          InsightsList(
            insights: insights,
          ),
        ],
      ),
    );
  }
}
