class StatisticsEngine {
  const StatisticsEngine({
    this.overviewCalculator = const OverviewCalculator(),
    this.weeklyCalculator = const WeeklyStatisticsCalculator(),
    this.monthlyCalculator = const MonthlyStatisticsCalculator(),
    this.performanceCalculator = const PerformanceCalculator(),
    this.trendCalculator = const TrendCalculator(),
    this.insightCalculator = const InsightCalculator(),
  });

  final OverviewCalculator overviewCalculator;
  final WeeklyStatisticsCalculator weeklyCalculator;
  final MonthlyStatisticsCalculator monthlyCalculator;
  final PerformanceCalculator performanceCalculator;
  final TrendCalculator trendCalculator;
  final InsightCalculator insightCalculator;

  StatisticsSummary calculate(StatisticsInput input) {
    return StatisticsSummary(
      overview: overviewCalculator.calculate(input),
      weekly: weeklyCalculator.calculate(input),
      monthly: monthlyCalculator.calculate(input),
      performance: performanceCalculator.calculate(input),
      trends: trendCalculator.calculate(input),
      insights: insightCalculator.calculate(input),
    );
  }
}
