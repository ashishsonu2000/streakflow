import '../../../habits/domain/models/habit.dart';
import '../../../habits/domain/models/habit_log.dart';

import '../models/completion_trend.dart';
import '../models/habit_performance.dart';
import '../models/insight.dart';
import '../models/monthly_statistics.dart';
import '../models/overview_statistics.dart';
import '../models/statistics_summary.dart';
import '../models/weekly_statistics.dart';

class StatisticsBuilder {
  const StatisticsBuilder();

  StatisticsSummary build({
    required List<Habit> habits,
    required List<HabitLog> logs,
  }) {
    return StatisticsSummary(
      overview: const OverviewCalculator().calculate(
        habits: habits,
        logs: logs,
      ),
      weekly: const WeeklyStatisticsCalculator().calculate(
        habits: habits,
        logs: logs,
      ),
      monthly: const MonthlyStatisticsCalculator().calculate(
        habits: habits,
        logs: logs,
      ),
      performance: const PerformanceCalculator().calculate(
        habits: habits,
        logs: logs,
      ),
      trends: const TrendCalculator().calculate(
        habits: habits,
        logs: logs,
      ),
      insights: const InsightCalculator().calculate(
        habits: habits,
        logs: logs,
      ),
    );
  }
}
