import '../../../../habits/domain/models/habit.dart';
import '../../../../habits/domain/models/habit_log.dart';

class PerfectDayCalculator {
  const PerfectDayCalculator();

  int calculate(
    List<Habit> habits,
    List<HabitLog> logs,
  ) {
    if (habits.isEmpty) {
      return 0;
    }

    final completedPerDay = <DateTime, int>{};

    for (final log in logs) {
      if (log.completedAt == null) {
        continue;
      }

      final date = DateTime(
        log.date.year,
        log.date.month,
        log.date.day,
      );

      completedPerDay.update(
        date,
        (value) => value + 1,
        ifAbsent: () => 1,
      );
    }

    return completedPerDay.values
        .where(
          (count) => count >= habits.length,
        )
        .length;
  }
}
