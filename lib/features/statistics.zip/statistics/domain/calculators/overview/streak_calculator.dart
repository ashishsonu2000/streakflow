import '../../../../habits/domain/models/habit_log.dart';

class StreakResult {
  const StreakResult({
    required this.current,
    required this.best,
  });

  final int current;
  final int best;
}

class StreakCalculator {
  const StreakCalculator();

  StreakResult calculate(
    List<HabitLog> logs,
  ) {
    if (logs.isEmpty) {
      return const StreakResult(
        current: 0,
        best: 0,
      );
    }

    final completedDates = logs
        .where((e) => e.completedAt != null)
        .map(
          (e) => DateTime(
            e.date.year,
            e.date.month,
            e.date.day,
          ),
        )
        .toSet()
        .toList()
      ..sort();

    if (completedDates.isEmpty) {
      return const StreakResult(
        current: 0,
        best: 0,
      );
    }

    int best = 1;
    int streak = 1;

    for (var i = 1; i < completedDates.length; i++) {
      final diff = completedDates[i].difference(completedDates[i - 1]).inDays;

      if (diff == 1) {
        streak++;
      } else {
        streak = 1;
      }

      if (streak > best) {
        best = streak;
      }
    }

    return StreakResult(
      current: streak,
      best: best,
    );
  }
}
