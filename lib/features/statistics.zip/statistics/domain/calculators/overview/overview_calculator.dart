import '../../../../habits/domain/models/habit.dart';
import '../../../../habits/domain/models/habit_log.dart';

import '../../models/overview_statistics.dart';

import 'perfect_day_calculator.dart';
import 'streak_calculator.dart';

class OverviewCalculator {
  const OverviewCalculator();

  OverviewStatistics calculate({
    required List<Habit> habits,
    required List<HabitLog> logs,
  }) {
    final completed = logs.where(
      (e) => e.completedAt != null,
    );

    final completionRate = logs.isEmpty ? 0 : completed.length / logs.length;

    final xp = completed.fold<int>(
      0,
      (sum, e) => sum + e.xpEarned,
    );

    final duration = completed.fold<int>(
      0,
      (sum, e) => sum + e.durationMinutes,
    );

    final streak = const StreakCalculator().calculate(
      logs,
    );

    final perfectDays = const PerfectDayCalculator().calculate(
      habits,
      logs,
    );

    return OverviewStatistics(
      completionRate: completionRate,
      currentStreak: streak.current,
      bestStreak: streak.best,
      totalHabits: habits.length,
      totalCompletions: completed.length,
      totalXP: xp,
      totalDurationMinutes: duration,
      perfectDays: perfectDays,
    );
  }
}
